@echo off
set APP_HOME=%~dp0
set GRADLE_VERSION=8.13
set GRADLE_HOME=%USERPROFILE%\.gradle\wrapper\ddui\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%USERPROFILE%\.gradle\wrapper\ddui\gradle-%GRADLE_VERSION%-bin.zip" powershell -NoProfile -Command "New-Item -ItemType Directory -Force '%USERPROFILE%\.gradle\wrapper\ddui' ^| Out-Null; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%USERPROFILE%\.gradle\wrapper\ddui\gradle-%GRADLE_VERSION%-bin.zip'"
  powershell -NoProfile -Command "Expand-Archive -Force '%USERPROFILE%\.gradle\wrapper\ddui\gradle-%GRADLE_VERSION%-bin.zip' '%USERPROFILE%\.gradle\wrapper\ddui'"
)
call "%GRADLE_HOME%\bin\gradle.bat" -p "%APP_HOME%" %*
