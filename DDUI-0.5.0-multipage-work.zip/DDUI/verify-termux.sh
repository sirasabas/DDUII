#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
command -v java >/dev/null 2>&1 || fail 'Java is missing.'
command -v gradle >/dev/null 2>&1 || fail 'Gradle is missing. Install Gradle 9.9.x in Termux.'
command -v aapt2 >/dev/null 2>&1 || fail 'Termux aapt2 is missing.'

JAVA_MAJOR="$(java -version 2>&1 | awk -F'[".]' '/version/ {print $2; exit}')"
[[ "${JAVA_MAJOR:-0}" -ge 21 ]] || fail "Java 21 or newer is required (found ${JAVA_MAJOR:-unknown})."

if [[ -z "${ANDROID_HOME:-}" && -d "$HOME/lib/android-sdk" ]]; then
  export ANDROID_HOME="$HOME/lib/android-sdk"
  export ANDROID_SDK_ROOT="$ANDROID_HOME"
fi
[[ -n "${ANDROID_HOME:-}" && -d "$ANDROID_HOME" ]] || fail 'Set ANDROID_HOME to the installed Android SDK directory.'
[[ -d "$ANDROID_HOME/platforms/android-36" ]] || fail 'Android SDK Platform 36 is not installed.'
[[ -d "$ANDROID_HOME/build-tools/36.0.0" ]] || fail 'Android SDK Build Tools 36.0.0 are not installed.'

# Termux's native ARM64 aapt2 is required; the Maven-hosted binary may be x86_64.
PROP="$ROOT/gradle.properties"
touch "$PROP"
sed -i '/^android\.aapt2FromMavenOverride=/d' "$PROP"
printf '\nandroid.aapt2FromMavenOverride=%s\n' "$(command -v aapt2)" >> "$PROP"

printf '\n[1/3] Building DDUI...\n'
gradle assembleDebug --no-daemon
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
[[ -s "$APK" ]] || fail 'Gradle completed but the debug APK was not created.'

printf '\n[2/3] Verifying APK...\n'
if command -v apksigner >/dev/null 2>&1; then
  apksigner verify --verbose "$APK" || fail 'APK signature verification failed.'
else
  printf 'WARN: apksigner not found; signature verification skipped.\n'
fi

printf '\n[3/3] Result\nAPK: %s\n' "$APK"
ls -lh "$APK"

if [[ "${INSTALL:-0}" == "1" ]]; then
  command -v adb >/dev/null 2>&1 || fail 'INSTALL=1 requested but adb is missing.'
  adb get-state >/dev/null 2>&1 || fail 'No ADB device is connected. Enable Wireless debugging and pair/connect first.'
  adb install -r "$APK"
  printf '\nInstalled. Set DDUI as the default Home app in Android settings.\n'
fi
