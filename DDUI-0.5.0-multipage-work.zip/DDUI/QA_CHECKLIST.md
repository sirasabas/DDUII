# DDUI 0.5.0 QA checklist

This checklist is intentionally not marked passed. It is the release gate for the first device-tested build.

## Build and installation
- [ ] `gradle assembleDebug --no-daemon` completes on Termux ARM64 with the native `aapt2` override.
- [ ] APK installs on Android 10+ and can be selected as the default HOME app.
- [ ] Existing 0.2.0 installation upgrades without losing preferences.
- [ ] Fresh install starts without crash and displays installed launcher activities.

## Home and app management
- [ ] Clock updates while DDUI remains in the foreground.
- [ ] App launch, app info, uninstall, hide/unhide and favourite pinning work.
- [ ] Favourite ordering persists after force-stop/reboot.
- [ ] Pinning more than 8 apps creates pages; horizontal swipes and page indicators navigate correctly.
- [ ] Page navigation clamps correctly after removing apps and never produces a blank out-of-range page.
- [ ] Folder create, rename, delete, add and remove operations persist.
- [ ] App drawer search and category filters do not crash with zero results or many apps.
- [ ] Usage and recently-installed sorting update correctly.
- [ ] Compatible icon pack maps expected icons; unmapped icons fall back cleanly.

## Gestures and visual settings
- [ ] Each configured swipe direction performs the selected action in its intended gesture zone.
- [ ] Vertical scrolling through long home content and widgets remains usable.
- [ ] Swipe-down disabled state does not trigger Control Centre.
- [ ] Light/dark/system themes have legible status/navigation bar icons.
- [ ] Rotation and tablet-width changes recalculate grid layout.
- [ ] Icon sizes, shapes, labels, columns and accent colour persist.
- [ ] Animations can run repeatedly without stale views or crashes.

## Widgets and notifications
- [ ] Widget picker returns and binds a widget ID.
- [ ] Widgets requiring configuration complete the configure flow.
- [ ] Cancelled widget picks release the allocated ID.
- [ ] Widget removal releases the ID and persists.
- [ ] Notification access off does not crash DDUI.
- [ ] Notification access on displays counts and updates when notifications are posted/removed.
- [ ] Revoking notification access while running does not crash the service.

## Backup and restore
- [ ] Export produces valid JSON with the DDUI backup marker.
- [ ] Restore of a valid backup restores themes, favourites, folders, hidden apps and widget references.
- [ ] Invalid or unrelated JSON is rejected without clearing current preferences.
- [ ] Restore after reinstall handles packages/widgets that are no longer installed or available.

## Device-specific validation
- [ ] AQUOS R8 Pro / Android 16 gesture navigation and cutout layout.
- [ ] Redmi 12 5G / HyperOS 2 memory pressure and widget behavior.
- [ ] At least one Android 10/11 device and one Android 14/15/16 device.
- [ ] Battery use and memory use after 24 hours of launcher uptime.


## Original DDUI icon pack
- [ ] Settings → Icon pack → DDUI Original applies bundled artwork to mapped apps.
- [ ] Settings → Icon pack → System icons restores platform-provided icons.
- [ ] A selected third-party `appfilter.xml` pack overrides DDUI artwork.
- [ ] Unmapped applications keep their original icons.
- [ ] Icons remain crisp at all configured icon sizes and on high-density displays.
- [ ] Notification badges remain visible above the custom icon artwork.
