# DDUI 0.5.0

DDUI is an independently implemented Android launcher inspired by the interaction patterns and visual language of modern Android home screens, including HyperOS 3. It does not contain Xiaomi's proprietary launcher code or assets and is not affiliated with Xiaomi.

## Included

### Home and app organisation
- Wallpaper-backed home screen, live clock/date, favourites and dock.
- Adaptive launcher icon with Android themed-icon monochrome layer.
- Multi-page home workspace: up to 32 pinned apps, 8 per page, swipe navigation and tappable page indicators.
- Favourite ordering editor; pin/unpin apps from the app drawer.
- User-created folders with rename/delete controls, app removal and persistent membership.
- Android AppWidgetHost integration, widget selection, widget configuration and removal.
- Long-press app actions: app shortcuts, favourites, folder assignment, app info, hide and uninstall.
- App drawer search and category filters.
- App sorting by name, usage count or install date.
- Configurable home/drawer columns, icon size, labels, icon shape and accent colour.

### Visual customisation and motion
- Original DDUI icon artwork is bundled locally in `res/drawable-nodpi`; no network access or external asset download is required.
- Light, dark and system themes.
- Original DDUI icon family with 24 custom-drawn, high-resolution PNG app icons (phone, messages, contacts, browser, camera, gallery, music, video, files, settings, calendar, clock, weather, notes, calculator, compass, downloads, security, recorder, mail, maps, Play Store, tools and themes).
- Built-in icon mapping for common Android/Google/Samsung/Xiaomi apps, with system-icon fallback for unmapped apps.
- Compatible third-party icon pack support using the standard `appfilter.xml` mapping; selected third-party packs take precedence over DDUI Original.
- Wallpaper visibility, Squircle/Rounded/Circle icon frames.
- Spring, Smooth and Soft transitions; staggered icon entrance and edit-sheet motion.
- Haptic feedback setting.

### Gestures and quick surfaces
- Configurable swipe-up/down/left/right actions; vertical gesture zones preserve scrolling through widget/home content.
- DDUI Discover page with selectable Google, DuckDuckGo or Bing web search.
- Google app hand-off when installed; Google Discover itself remains owned by the Google app.
- DDUI Control Centre shortcuts to Android Wi-Fi, Bluetooth, display, sound, battery and system settings.

### Notifications and data
- Optional notification-count badges via Android Notification Listener access, including live refresh.
- Live badge refresh while DDUI is visible.
- JSON backup/export and restore/import through Android's document picker.
- Hidden-app management and persistent preferences.

## Home page navigation

Pin more than eight apps to create additional home pages. Swipe horizontally across the home screen or tap a page indicator to move between pages. When there is no adjacent page, the configured left/right gesture action remains available. The dock remains shared across pages.

## Icon pack preview

The bundled original icon set is previewed in `design/icon-pack-preview.jpg`. In Settings → Icon pack, choose **DDUI Original**, **System icons**, or an installed compatible third-party pack.

## Permissions and setup

- **Notification access** is optional. Enable it in DDUI Settings → Notification access to display app notification counts. DDUI reads active notification package/count metadata for badges; it does not need notification text for this feature.
- **Widgets** use Android's AppWidgetHost and the system widget picker. Some manufacturers may restrict widget binding or configuration.
- **Icon packs** must expose a compatible launcher theme intent and `appfilter.xml` resource.
- **Shizuku is not required** for the launcher features above. DDUI does not request privileged shell access merely to perform normal home-screen operations. Android's protected notification shade, lock screen, system Recents and system animation pipeline remain controlled by the OS.

## Build in Termux (ARM64)

Required: Java 21, Gradle 9.9.x, Android SDK Platform 36, Build Tools 36.x, Platform Tools and accepted SDK licences.

```bash
cd ~/projects/DDUI/DDUI
./verify-termux.sh
```

The script checks Java/SDK prerequisites, configures the native ARM64 Termux `aapt2` override, builds the APK and verifies its signature when `apksigner` is installed. To also install over an existing build after connecting ADB, use `INSTALL=1 ./verify-termux.sh`.

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Install:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

If Android reports a signing-certificate mismatch from an older local build, uninstall the old DDUI first (this clears DDUI's local settings), then install the new APK.

## Verification status

- Manifest and resource XML are checked for well-formedness.
- Kotlin source was checked for parser-level syntax errors.
- This build environment does not contain an Android SDK, Gradle installation or connected Android device. Therefore this package has **not** been APK-compiled or runtime-tested here. Do not treat a source-only check as a successful Android build. Complete the build and device test in Termux before setting DDUI as the default launcher.
