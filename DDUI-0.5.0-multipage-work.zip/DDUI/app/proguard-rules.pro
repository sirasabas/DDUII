# DDUI launcher rules
