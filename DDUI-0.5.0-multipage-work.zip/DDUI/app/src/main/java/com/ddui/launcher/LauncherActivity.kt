package com.ddui.launcher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.os.Build
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Process
import android.os.Handler
import android.os.Looper
import android.content.pm.LauncherApps
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.content.res.Configuration
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class LauncherActivity : Activity() {
    private data class AppEntry(val label: String, val packageName: String, val activityName: String, val icon: android.graphics.drawable.Drawable)
    private data class LauncherAction(val title: String, val detail: String, val symbol: String, val action: () -> Unit)

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private var apps: List<AppEntry> = emptyList()
    private var iconPackMap: Map<String, Int> = emptyMap()
    private var iconPackResources: android.content.res.Resources? = null
    private var drawerOpen = false
    private var screen = "home"
    private var downX = 0f
    private var downY = 0f
    private var currentPage = 0
    private var searchText = ""
    private lateinit var clockView: TextView
    private lateinit var clockSubView: TextView
    private val clockHandler = Handler(Looper.getMainLooper())
    private val clockTicker = object : Runnable {
        override fun run() {
            if (::clockView.isInitialized && screen == "home") {
                val now = Date()
                clockView.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
                clockSubView.text = SimpleDateFormat("EEEE  ·  MMMM d", Locale.getDefault()).format(now)
                clockHandler.postDelayed(this, 30_000L)
            }
        }
    }
    private val widgetHostId = 0xDD01
    private lateinit var widgetHost: AppWidgetHost
    private val widgetManager by lazy { AppWidgetManager.getInstance(this) }
    private val widgetRequest = 7101
    private val backupExportRequest = 7102
    private val backupImportRequest = 7103
    private val widgetConfigureRequest = 7104
    private var pendingWidgetId = -1
    private var notificationReceiverRegistered = false
    private val notificationReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (screen == "home") renderHome(false)
        }
    }

    private val blue: Int
        get() = when (prefs.getString("accent", "Blue")) {
            "Violet" -> Color.rgb(132, 104, 230)
            "Mint" -> Color.rgb(39, 164, 145)
            "Rose" -> Color.rgb(220, 104, 139)
            else -> Color.rgb(66, 126, 235)
        }
    private val lightInk = Color.rgb(27, 31, 39)
    private val lightMuted = Color.rgb(105, 112, 124)
    private val darkInk = Color.rgb(244, 246, 250)
    private val darkMuted = Color.rgb(177, 184, 197)
    private val lightSurface = Color.argb(225, 255, 255, 255)
    private val darkSurface = Color.argb(225, 35, 39, 48)
    private val ink get() = if (isDark()) darkInk else lightInk
    private val muted get() = if (isDark()) darkMuted else lightMuted
    private val surface get() = if (isDark()) darkSurface else lightSurface
    private val backgroundColor get() = if (isDark()) Color.rgb(20, 23, 30) else Color.rgb(232, 237, 246)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ddui", MODE_PRIVATE)
        currentPage = prefs.getInt("home_page", 0)
        widgetHost = AppWidgetHost(this, widgetHostId)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        applySystemBars()
        loadApps()
        renderHome(false)
    }

    override fun onStart() {
        super.onStart()
        try { widgetHost.startListening() } catch (_: Exception) { }
    }

    override fun onStop() {
        try { widgetHost.stopListening() } catch (_: Exception) { }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (::prefs.isInitialized) loadApps()
        if (screen == "home" && ::root.isInitialized) renderHome(false)
        clockHandler.removeCallbacks(clockTicker)
        clockHandler.post(clockTicker)
        if (!notificationReceiverRegistered) {
            val filter = IntentFilter("$packageName.NOTIFICATIONS_UPDATED")
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(notificationReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            else { registerReceiver(notificationReceiver, filter) }
            notificationReceiverRegistered = true
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        loadApps()
        when (screen) {
            "home" -> renderHome(false)
            "drawer" -> showDrawer()
            "discover" -> showDiscover()
            "control" -> showControlCenter()
            "settings" -> showSettings()
            else -> renderHome(false)
        }
    }

    override fun onPause() {
        clockHandler.removeCallbacks(clockTicker)
        if (notificationReceiverRegistered) {
            try { unregisterReceiver(notificationReceiver) } catch (_: Exception) { }
            notificationReceiverRegistered = false
        }
        super.onPause()
    }

    private fun applySystemBars() {
        var flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        if (!isDark()) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = flags
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
    }

    private fun isDark(): Boolean = when (prefs.getString("theme", "light")) {
        "dark" -> true
        "system" -> (resources.configuration.uiMode and 0x30) == 0x20
        else -> false
    }

    private fun loadApps() {
        val hidden = prefs.getStringSet("hidden_apps", emptySet()) ?: emptySet()
        val pack = prefs.getString("icon_pack", "builtin") ?: "builtin"
        iconPackMap = if (pack.isNotBlank() && pack != "builtin" && pack != "system") loadIconPackMap(pack) else emptyMap()
        val launcher = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = packageManager.queryIntentActivities(launcher, PackageManager.MATCH_ALL)
            .mapNotNull { ri ->
                val ai = ri.activityInfo ?: return@mapNotNull null
                try {
                    val base = ri.loadIcon(packageManager)
                    val key = "${ai.packageName}/${ai.name}"
                    val externalIcon = iconPackMap[key]?.let { id ->
                        try { iconPackResources?.getDrawable(id, theme) } catch (_: Exception) { null }
                    }
                    val builtInIcon = if (pack != "system") resolveBuiltInIcon(ri.loadLabel(packageManager).toString(), ai.packageName) else null
                    val icon = externalIcon ?: builtInIcon ?: base
                    AppEntry(ri.loadLabel(packageManager).toString(), ai.packageName, ai.name, icon)
                } catch (_: Exception) { null }
            }
            .filter { it.packageName != packageName && !hidden.contains(it.packageName) }
            .distinctBy { it.packageName }
            .let { entries ->
                when (prefs.getString("app_sort", "Name")) {
                    "Usage" -> entries.sortedByDescending { usageCount(it.packageName) }
                    "Recently added" -> entries.sortedByDescending { appInstallTime(it.packageName) }
                    else -> entries.sortedBy { it.label.lowercase(Locale.getDefault()) }
                }
            }
    }

    private fun loadIconPackMap(pack: String): Map<String, Int> {
        iconPackResources = null
        if (pack.isBlank()) return emptyMap()
        return try {
            val res = packageManager.getResourcesForApplication(pack)
            iconPackResources = res
            val xmlId = res.getIdentifier("appfilter", "xml", pack)
            if (xmlId == 0) return emptyMap()
            val parser = res.getXml(xmlId)
            val result = mutableMapOf<String, Int>()
            try {
                var event = parser.eventType
                while (event != XmlPullParser.END_DOCUMENT) {
                    if (event == XmlPullParser.START_TAG && parser.name == "item") {
                        val component = parser.getAttributeValue(null, "component")
                        val drawable = parser.getAttributeValue(null, "drawable")
                        if (!component.isNullOrBlank() && !drawable.isNullOrBlank()) {
                            val raw = component.substringAfter('{', "").substringBefore('}')
                            val parts = raw.split('/', limit = 2)
                            if (parts.size == 2) {
                                val cls = if (parts[1].startsWith('.')) parts[0] + parts[1] else parts[1]
                                val id = res.getIdentifier(drawable, "drawable", pack)
                                if (id != 0) result["${parts[0]}/$cls"] = id
                            }
                        }
                    }
                    event = parser.next()
                }
            } finally { parser.close() }
            result
        } catch (_: Exception) { emptyMap() }
    }

    private fun showIconPackPicker() {
        val actions = listOf("org.adw.launcher.THEMES", "com.novalauncher.THEME", "com.teslacoilsw.launcher.THEME", "com.anddoes.launcher.THEME")
        val packages = actions.flatMap { action ->
            try { packageManager.queryIntentActivities(Intent(action), PackageManager.MATCH_ALL).map { it.activityInfo.packageName } }
            catch (_: Exception) { emptyList() }
        }.distinct()
        val labels = packages.map { pkg ->
            try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() }
            catch (_: Exception) { pkg }
        }
        val selected = prefs.getString("icon_pack", "builtin") ?: "builtin"
        val entries = listOf("DDUI Original · 24 icons", "System icons") + labels
        val selectedIndex = when (selected) {
            "builtin" -> 0
            "system", "" -> 1
            else -> (packages.indexOf(selected) + 2).coerceAtLeast(1)
        }
        AlertDialog.Builder(this).setTitle("Icon pack")
            .setSingleChoiceItems(entries.toTypedArray(), selectedIndex) { dialog, which ->
                val value = when (which) { 0 -> "builtin"; 1 -> "system"; else -> packages[which - 2] }
                prefs.edit().putString("icon_pack", value).apply()
                dialog.dismiss(); loadApps(); renderHome()
            }.setNegativeButton("Cancel", null).show()
    }

    /** Original DDUI icon family. External icon packs take precedence when selected. */
    private fun resolveBuiltInIcon(label: String, pkg: String): android.graphics.drawable.Drawable? {
        val p = pkg.lowercase(Locale.ROOT)
        val l = label.lowercase(Locale.ROOT)
        val icon = when {
            p in setOf("com.google.android.dialer", "com.android.dialer", "com.android.phone", "com.samsung.android.dialer") || l.contains("phone") || l.contains("電話") -> R.drawable.icpack_phone
            p in setOf("com.google.android.apps.messaging", "com.android.messaging", "com.samsung.android.messaging") || l.contains("messages") || l.contains("メッセージ") -> R.drawable.icpack_messages
            p in setOf("com.google.android.contacts", "com.android.contacts", "com.samsung.android.app.contacts") || l.contains("contacts") || l.contains("連絡先") -> R.drawable.icpack_contacts
            p in setOf("com.android.chrome", "com.google.android.apps.chrome") || l == "chrome" -> R.drawable.icpack_browser
            p in setOf("com.android.camera", "com.android.camera2", "com.google.android.camera", "com.sec.android.app.camera") || l.contains("camera") || l.contains("カメラ") -> R.drawable.icpack_camera
            p in setOf("com.google.android.apps.photos", "com.miui.gallery", "com.sec.android.gallery3d") || l.contains("photos") || l.contains("gallery") || l.contains("フォト") || l.contains("ギャラリー") -> R.drawable.icpack_gallery
            p in setOf("com.google.android.music", "com.google.android.apps.youtube.music", "com.spotify.music", "com.sec.android.app.music") || p.contains("music") || l.contains("music") || l.contains("音楽") || l.contains("spotify") -> R.drawable.icpack_music
            p in setOf("com.google.android.youtube", "com.google.android.videos") || l.contains("youtube") || l.contains("video") || l.contains("動画") -> R.drawable.icpack_video
            p in setOf("com.google.android.documentsui", "com.sec.android.app.myfiles", "com.mi.android.globalFileexplorer") || l.contains("files") || l.contains("file") || l.contains("ファイル") -> R.drawable.icpack_files
            p in setOf("com.android.settings", "com.android.settings.intelligence", "com.miui.securitycenter") || l.contains("settings") || l.contains("設定") -> R.drawable.icpack_settings
            p in setOf("com.google.android.calendar", "com.android.calendar", "com.samsung.android.calendar") || l.contains("calendar") || l.contains("カレンダー") -> R.drawable.icpack_calendar
            p in setOf("com.google.android.deskclock", "com.android.deskclock", "com.sec.android.app.clockpackage") || l.contains("clock") || l.contains("時計") || l.contains("アラーム") -> R.drawable.icpack_clock
            p in setOf("com.google.android.apps.weather", "com.miui.weather2") || l.contains("weather") || l.contains("天気") -> R.drawable.icpack_weather
            p in setOf("com.google.android.keep", "com.samsung.android.app.notes") || l.contains("notes") || l.contains("メモ") -> R.drawable.icpack_notes
            p in setOf("com.google.android.calculator", "com.android.calculator2") || l.contains("calculator") || l.contains("電卓") -> R.drawable.icpack_calculator
            p in setOf("com.google.android.apps.maps", "com.google.android.apps.mapslite") || l.contains("maps") || l.contains("マップ") -> R.drawable.icpack_maps
            p in setOf("com.google.android.gm", "com.microsoft.office.outlook") || l.contains("gmail") || l.contains("mail") || l.contains("メール") -> R.drawable.icpack_mail
            p in setOf("com.android.vending") || l.contains("play store") || l.contains("play ストア") -> R.drawable.icpack_play
            p in setOf("com.google.android.apps.nbu.files") || l.contains("download") || l.contains("ダウンロード") -> R.drawable.icpack_downloads
            p.contains("security") || l.contains("security") || l.contains("セキュリティ") -> R.drawable.icpack_security
            p.contains("recorder") || l.contains("recorder") || l.contains("レコーダー") -> R.drawable.icpack_recorder
            p.contains("compass") || l.contains("compass") || l.contains("コンパス") -> R.drawable.icpack_compass
            p.contains("theme") || l.contains("themes") || l.contains("テーマ") -> R.drawable.icpack_themes
            l.contains("tools") || l.contains("ツール") -> R.drawable.icpack_tools
            else -> null
        } ?: return null
        return try { getDrawable(icon) } catch (_: Exception) { null }
    }

    private fun renderHome(animate: Boolean = true) {
        applySystemBars()
        screen = "home"
        drawerOpen = false
        root = GestureFrameLayout(this).apply { setBackgroundColor(backgroundColor) }
        val wallpaper = try { WallpaperManager.getInstance(this).drawable } catch (_: Exception) { null }
        if (wallpaper != null && prefs.getBoolean("show_wallpaper", true)) root.background = wallpaper
        val scroll = ScrollView(this).apply {
            isFillViewport = true; clipToPadding = false; overScrollMode = View.OVER_SCROLL_NEVER
            setOnLongClickListener { showEditPanel(); true }
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(48), dp(22), dp(22))
        }
        scroll.addView(content, ScrollView.LayoutParams(-1, -1))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val date = TextView(this).apply {
            text = SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(Date())
            textSize = 14f; setTextColor(ink); alpha = .9f
        }
        header.addView(date, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(actionText("⚙", blue) { showSettings() }, LinearLayout.LayoutParams(dp(42), dp(42)))
        val weather = pill("◉  DDUI", 13f).apply { setOnClickListener { showControlCenter() } }
        header.addView(weather)
        content.addView(header)

        clockView = TextView(this).apply {
            text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            textSize = 62f; setTextColor(ink); typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setPadding(0, dp(20), 0, dp(0))
        }
        content.addView(clockView)
        clockSubView = TextView(this).apply { text = SimpleDateFormat("EEEE  ·  MMMM d", Locale.getDefault()).format(Date()); textSize = 13f; setTextColor(muted); setPadding(0, 0, 0, dp(18)) }
        content.addView(clockSubView)

        val search = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(16), 0); background = rounded(surface, 26f)
            elevation = dp(2).toFloat()
        }
        search.addView(TextView(this).apply { text = "⌕"; textSize = 27f; setTextColor(muted) })
        search.addView(TextView(this).apply { text = "Search apps and the web"; textSize = 14f; setTextColor(muted); setPadding(dp(10), 0, 0, 0) }, LinearLayout.LayoutParams(0, dp(52), 1f))
        search.addView(TextView(this).apply { text = "✦"; textSize = 19f; setTextColor(blue) })
        search.setOnClickListener { showDiscover() }
        content.addView(search, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(16) })

        val widgetIds = prefs.getStringSet("widget_ids", emptySet())?.toList().orEmpty()
        if (widgetIds.isNotEmpty()) {
            widgetIds.forEach { raw ->
                val id = raw.toIntOrNull() ?: return@forEach
                try {
                    val info = widgetManager.getAppWidgetInfo(id) ?: return@forEach
                    val hostView = widgetHost.createView(this, id, info)
                    hostView.setOnLongClickListener {
                        AlertDialog.Builder(this).setTitle("Remove widget?").setMessage("Remove this widget from DDUI?")
                            .setNegativeButton("Cancel", null).setPositiveButton("Remove") { _, _ ->
                                val updated = (prefs.getStringSet("widget_ids", emptySet()) ?: emptySet()).toMutableSet()
                                updated.remove(id.toString())
                                prefs.edit().putStringSet("widget_ids", updated).apply()
                                widgetHost.deleteAppWidgetId(id)
                                renderHome()
                            }.show()
                        true
                    }
                    content.addView(hostView, LinearLayout.LayoutParams(-1, dp(150)).apply { bottomMargin = dp(12) })
                } catch (_: Exception) { }
            }
        } else {
            val cards = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            cards.addView(infoTile("BATTERY", "${batteryPercent()}% · Device status", "▰"), LinearLayout.LayoutParams(0, dp(94), 1f))
            cards.addView(Space(this), LinearLayout.LayoutParams(dp(10), 1))
            cards.addView(infoTile("QUICK NOTE", prefs.getString("note", "Tap to write something") ?: "Tap to write something", "✎"), LinearLayout.LayoutParams(0, dp(94), 1f))
            content.addView(cards, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
        }

        val section = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        section.addView(TextView(this).apply { text = "Favourites"; textSize = 19f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink) }, LinearLayout.LayoutParams(0, -2, 1f))
        section.addView(TextView(this).apply { text = "All apps  ›"; textSize = 13f; setTextColor(blue); setOnClickListener { showDrawer() } })
        content.addView(section, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        val favorites = favoriteApps()
        val homePageSize = 8
        val pageCount = ((favorites.size + homePageSize - 1) / homePageSize).coerceAtLeast(1)
        currentPage = currentPage.coerceIn(0, pageCount - 1)
        val pageFavorites = favorites.drop(currentPage * homePageSize).take(homePageSize)
        val folderNames = prefs.getStringSet("folders", emptySet()) ?: emptySet()
        if (folderNames.isNotEmpty()) {
            val folderStrip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            folderNames.sorted().forEach { folderName ->
                val folder = pill("▣  $folderName", 12f).apply {
                    setOnClickListener { showFolder(folderName) }
                    setOnLongClickListener { showFolderActions(folderName); true }
                }
                folderStrip.addView(folder, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(2), 0, dp(2), dp(8)) })
            }
            content.addView(folderStrip)
        }
        val homeColumns = if (resources.configuration.screenWidthDp >= 720) 6 else (prefs.getString("home_columns", "4")?.toIntOrNull() ?: 4).coerceIn(3, 6)
        val favGrid = GridLayout(this).apply { columnCount = homeColumns; useDefaultMargins = false }
        pageFavorites.forEach { app ->
            val cell = appIcon(app, false, true)
            favGrid.addView(cell, GridLayout.LayoutParams().apply { width = 0; height = dp(92); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(1), dp(2), dp(1), dp(3)) })
        }
        if (pageFavorites.isEmpty()) {
            content.addView(TextView(this).apply {
                text = "Pin apps from All apps to build this page"
                textSize = 13f; setTextColor(muted); gravity = Gravity.CENTER
                setPadding(dp(12), dp(22), dp(12), dp(22))
            }, LinearLayout.LayoutParams(-1, dp(82)))
        } else {
            content.addView(favGrid, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        }

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(surface, 30f); elevation = dp(5).toFloat()
        }
        val dockApps = favoriteApps().take(5)
        dockApps.forEach { app -> dock.addView(appIcon(app, true, false), LinearLayout.LayoutParams(0, dp(58), 1f)) }
        if (prefs.getBoolean("dock_enabled", true)) {
            content.addView(dock, LinearLayout.LayoutParams(-1, dp(74)).apply { topMargin = dp(4); bottomMargin = dp(10) })
        }
        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        repeat(pageCount) { index ->
            val dot = TextView(this).apply {
                text = if (index == currentPage) "●" else "○"
                textSize = 11f
                setTextColor(if (index == currentPage) blue else muted)
                gravity = Gravity.CENTER
                contentDescription = "Home page ${index + 1} of $pageCount"
                setOnClickListener { currentPage = index; prefs.edit().putInt("home_page", currentPage).apply(); renderHome(false) }
            }
            dots.addView(dot, LinearLayout.LayoutParams(dp(28), dp(28)))
        }
        if (pageCount < 4) {
            val addPage = TextView(this).apply {
                text = "+"; textSize = 14f; setTextColor(muted); gravity = Gravity.CENTER
                contentDescription = "Open app drawer to pin more apps"
                setOnClickListener { showDrawer() }
            }
            dots.addView(addPage, LinearLayout.LayoutParams(dp(28), dp(28)))
        }
        content.addView(dots, LinearLayout.LayoutParams(-1, dp(30)))

        root.setOnLongClickListener { showEditPanel(); true }
        content.setOnLongClickListener { showEditPanel(); true }
        setContentView(root)
        clockHandler.removeCallbacks(clockTicker)
        clockHandler.post(clockTicker)
        if (animate) animateScreen(root)
        animateChildren(content)
    }

    private fun favoriteApps(): List<AppEntry> {
        val ordered = prefs.getString("favorites_order", null)?.split('|')?.filter { it.isNotBlank() }
        if (!ordered.isNullOrEmpty()) return ordered.mapNotNull { pkg -> apps.firstOrNull { it.packageName == pkg } }.take(32)
        val saved = prefs.getStringSet("favorites", null)
        if (saved != null) return saved.mapNotNull { pkg -> apps.firstOrNull { it.packageName == pkg } }.take(32)
        val preferred = listOf("com.google.android.dialer", "com.google.android.apps.messaging", "com.android.chrome", "com.android.camera2", "com.google.android.youtube", "com.google.android.apps.photos", "com.android.settings", "com.google.android.gm")
        val result = preferred.mapNotNull { p -> apps.firstOrNull { it.packageName == p } }.toMutableList()
        apps.filter { it !in result }.take((8 - result.size).coerceAtLeast(0)).forEach { result.add(it) }
        return result.take(8)
    }

    private fun saveFavoriteOrder(items: List<AppEntry>) {
        prefs.edit().putString("favorites_order", items.joinToString("|") { it.packageName })
            .putStringSet("favorites", items.take(32).map { it.packageName }.toSet()).apply()
    }

    private fun showFavoriteOrganizer() {
        val items = favoriteApps().toMutableList()
        if (items.isEmpty()) return
        fun showList() {
            AlertDialog.Builder(this).setTitle("Arrange favourites")
                .setItems(items.mapIndexed { index, app -> "${index + 1}. ${app.label}" }.toTypedArray()) { _, index ->
                    val choices = arrayOf("Move up", "Move down", "Remove from favourites")
                    AlertDialog.Builder(this).setTitle(items[index].label).setItems(choices) { _, action ->
                        when (action) {
                            0 -> if (index > 0) { val item = items.removeAt(index); items.add(index - 1, item) }
                            1 -> if (index < items.lastIndex) { val item = items.removeAt(index); items.add(index + 1, item) }
                            2 -> items.removeAt(index)
                        }
                        saveFavoriteOrder(items)
                        renderHome()
                    }.show()
                }.setPositiveButton("Done") { _, _ -> saveFavoriteOrder(items); renderHome() }
                .setNegativeButton("Cancel", null).show()
        }
        showList()
    }

    private fun runGestureAction(action: String) {
        when (action) {
            "Control centre" -> showControlCenter()
            "App drawer" -> showDrawer()
            "Discover", "Search" -> showDiscover()
            "Home" -> renderHome()
            else -> Unit
        }
    }

    private fun handleHomeSwipe(dx: Float, dy: Float, startY: Float, viewHeight: Int): Boolean {
        if (screen != "home") return false
        if (abs(dx) > dp(75) && abs(dx) > abs(dy) * 1.15f) {
            val favouriteCount = favoriteApps().size
            val pageCount = ((favouriteCount + 7) / 8).coerceAtLeast(1)
            val targetPage = if (dx < 0) currentPage + 1 else currentPage - 1
            if (targetPage in 0 until pageCount) {
                currentPage = targetPage
                prefs.edit().putInt("home_page", currentPage).apply()
                renderHome()
            } else {
                val action = prefs.getString(if (dx > 0) "gesture_right" else "gesture_left", if (dx > 0) "Discover" else "App drawer") ?: "None"
                if (action != "None") runGestureAction(action)
            }
            return true
        }
        if (abs(dy) > dp(75) && abs(dy) > abs(dx) * 1.15f) {
            // Keep the centre of the home page vertically scrollable. Vertical launcher gestures
            // are reserved for the top and bottom gesture zones.
            val isTopGesture = dy > 0 && startY <= dp(112)
            val isBottomGesture = dy < 0 && startY >= viewHeight - dp(128)
            if (!isTopGesture && !isBottomGesture) return false
            val action = if (dy < 0) prefs.getString("gesture_up", "App drawer") else if (prefs.getBoolean("swipe_control", true)) prefs.getString("gesture_down", "Control centre") else "None"
            if (action != "None") runGestureAction(action ?: "None")
            return true
        }
        return false
    }

    private inner class GestureFrameLayout(context: Context) : FrameLayout(context) {
        private var startX = 0f
        private var startY = 0f
        override fun dispatchTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { startX = event.x; startY = event.y }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - startX
                    val dy = event.y - startY
                    if (handleHomeSwipe(dx, dy, startY, height)) {
                        val cancel = MotionEvent.obtain(event).apply { action = MotionEvent.ACTION_CANCEL }
                        super.dispatchTouchEvent(cancel)
                        cancel.recycle()
                        return true
                    }
                }
            }
            return super.dispatchTouchEvent(event)
        }
    }

    private fun showDrawer() {
        applySystemBars()
        screen = "drawer"
        drawerOpen = true
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(48), dp(20), dp(18)); setBackgroundColor(backgroundColor) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply { text = "All apps"; textSize = 30f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink) }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(actionText("✕") { renderHome() })
        page.addView(header)
        val search = EditText(this).apply {
            hint = "Search apps"; textSize = 16f; setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_SEARCH
            setTextColor(ink); setHintTextColor(muted); background = rounded(surface, 25f); setPadding(dp(18), 0, dp(18), 0)
        }
        page.addView(search, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(16); bottomMargin = dp(12) })
        lateinit var grid: GridLayout
        val categories = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        listOf("All", "Communication", "Media", "Tools").forEachIndexed { index, label ->
            val chip = pill(label, 12f).apply { setOnClickListener { populateApps(label, search.text.toString(), grid) } }
            categories.addView(chip, LinearLayout.LayoutParams(0, dp(38), 1f).apply { setMargins(dp(2), 0, dp(2), dp(8)) })
        }
        page.addView(categories)
        val scroll = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        grid = GridLayout(this).apply { columnCount = if (resources.configuration.screenWidthDp >= 600) 6 else (prefs.getString("columns", "4")?.toIntOrNull() ?: 4); useDefaultMargins = false }
        populateApps("All", "", grid)
        scroll.addView(grid)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { populateApps("All", s?.toString().orEmpty(), grid) }
            override fun afterTextChanged(s: Editable?) {}
        })
        setContentView(page)
        animateScreen(page)
    }

    private fun populateApps(category: String, query: String, grid: GridLayout) {
        grid.removeAllViews()
        val filtered = apps.filter { app ->
            val matches = app.label.contains(query, true) || app.packageName.contains(query, true)
            val cat = when (category) {
                "Communication" -> listOf("phone", "message", "mail", "chat", "discord", "line", "telegram").any { app.label.contains(it, true) || app.packageName.contains(it, true) }
                "Media" -> listOf("camera", "photo", "video", "music", "youtube", "gallery", "spotify").any { app.label.contains(it, true) || app.packageName.contains(it, true) }
                "Tools" -> listOf("setting", "file", "clock", "calculator", "browser", "chrome").any { app.label.contains(it, true) || app.packageName.contains(it, true) }
                else -> true
            }
            matches && cat
        }
        if (filtered.isEmpty()) {
            grid.addView(TextView(this).apply {
                text = if (query.isBlank()) "No apps in this category" else "No apps found for ‘$query’"
                textSize = 14f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(dp(16), dp(24), dp(16), dp(24))
            }, GridLayout.LayoutParams().apply { width = resources.displayMetrics.widthPixels - dp(40); height = dp(80); columnSpec = GridLayout.spec(0, grid.columnCount) })
        } else filtered.forEach { app ->
            grid.addView(appIcon(app, false, false), GridLayout.LayoutParams().apply {
                width = resources.displayMetrics.widthPixels / grid.columnCount - dp(12); height = dp(104)
                setMargins(dp(2), dp(4), dp(2), dp(4))
            })
        }
    }

    private fun appIcon(app: AppEntry, dock: Boolean, favorite: Boolean): View {
        val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(3), dp(3), dp(3), dp(3)) }
        val iconSize = prefs.getString("icon_size", if (dock) "42" else "50")?.toIntOrNull() ?: if (dock) 42 else 50
        val frame = FrameLayout(this).apply { background = iconFrameBackground(); elevation = if (dock) 0f else dp(1).toFloat() }
        val icon = ImageView(this).apply { setImageDrawable(app.icon); scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(dp(5), dp(5), dp(5), dp(5)) }
        frame.addView(icon, FrameLayout.LayoutParams(-1, -1))
        val badgeCount = notificationCount(app.packageName)
        if (badgeCount > 0 && prefs.getBoolean("notification_badges", true)) {
            val badge = TextView(this).apply {
                text = if (badgeCount > 99) "99+" else badgeCount.toString()
                textSize = 8f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                setPadding(dp(4), 0, dp(4), 0); background = GradientDrawable().apply { setColor(Color.rgb(235, 65, 85)); cornerRadius = dp(12).toFloat() }
                elevation = dp(4).toFloat()
            }
            frame.addView(badge, FrameLayout.LayoutParams(-2, dp(17), Gravity.TOP or Gravity.END))
        }
        cell.addView(frame, LinearLayout.LayoutParams(dp(iconSize), dp(iconSize)))
        if (!dock && prefs.getBoolean("show_labels", true)) {
            cell.addView(TextView(this).apply { text = app.label; textSize = 10.5f; setTextColor(ink); gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(-1, dp(22)))
        }
        cell.setOnClickListener {
            launch(app.packageName)
            if (prefs.getBoolean("haptics", true)) cell.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
        cell.setOnLongClickListener { showAppActions(app); true }
        cell.scaleX = .88f; cell.scaleY = .88f; cell.alpha = .0f
        cell.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay((apps.indexOf(app).coerceAtMost(12) * 12).toLong()).setDuration(260).setInterpolator(OvershootInterpolator(1.15f)).start()
        return cell
    }

    private fun launch(pkg: String) {
        val counts = (prefs.getStringSet("app_usage", emptySet()) ?: emptySet()).toMutableSet()
        val old = counts.firstOrNull { it.startsWith("$pkg=") }?.substringAfter('=')?.toIntOrNull() ?: 0
        counts.removeAll { it.startsWith("$pkg=") }; counts.add("$pkg=${old + 1}")
        prefs.edit().putStringSet("app_usage", counts).apply()
        try { packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it); overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out) } }
        catch (_: Exception) { Toast.makeText(this, "Unable to open app", Toast.LENGTH_SHORT).show() }
    }

    private fun showAppActions(app: AppEntry) {
        val favoriteSet = (prefs.getStringSet("favorites", favoriteApps().map { it.packageName }.toSet()) ?: emptySet()).toMutableSet()
        val already = favoriteSet.contains(app.packageName)
        val items = arrayOf(if (already) "Remove from favourites" else "Add to favourites", "App shortcuts", "Add to folder", "App info", "Hide app", "Uninstall")
        AlertDialog.Builder(this).setTitle(app.label).setItems(items) { _, which ->
            when (which) {
                0 -> {
                    val ordered = favoriteApps().toMutableList()
                    if (already) ordered.removeAll { it.packageName == app.packageName } else if (ordered.none { it.packageName == app.packageName }) ordered.add(app)
                    saveFavoriteOrder(ordered)
                    if (screen == "home") renderHome()
                }
                1 -> showAppShortcuts(app)
                2 -> addAppToFolder(app)
                3 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(android.net.Uri.parse("package:${app.packageName}")))
                4 -> { val hidden = (prefs.getStringSet("hidden_apps", emptySet()) ?: emptySet()).toMutableSet(); hidden.add(app.packageName); prefs.edit().putStringSet("hidden_apps", hidden).apply(); loadApps(); if (screen == "drawer") showDrawer() else renderHome() }
                5 -> startActivity(Intent(Intent.ACTION_DELETE).setData(android.net.Uri.parse("package:${app.packageName}")))
            }
        }.show()
    }

    private fun showAppShortcuts(app: AppEntry) {
        try {
            val launcherApps = getSystemService(LauncherApps::class.java)
            val query = LauncherApps.ShortcutQuery()
                .setPackage(app.packageName)
                .setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED)
            val shortcuts = launcherApps.getShortcuts(query, Process.myUserHandle()).orEmpty()
            if (shortcuts.isEmpty()) {
                Toast.makeText(this, "No shortcuts available for ${app.label}", Toast.LENGTH_SHORT).show()
                return
            }
            val labels = shortcuts.map { it.shortLabel?.toString() ?: it.id }.toTypedArray()
            AlertDialog.Builder(this).setTitle("${app.label} shortcuts").setItems(labels) { _, which ->
                try { launcherApps.startShortcut(app.packageName, shortcuts[which].id, null, null, Process.myUserHandle()) }
                catch (_: Exception) { Toast.makeText(this, "Unable to open shortcut", Toast.LENGTH_SHORT).show() }
            }.show()
        } catch (_: Exception) {
            Toast.makeText(this, "App shortcuts are unavailable", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createFolderDialog() {
        val input = EditText(this).apply { hint = "Folder name"; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("Create folder").setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val folders = (prefs.getStringSet("folders", emptySet()) ?: emptySet()).toMutableSet()
                    if (folders.contains(name)) {
                        Toast.makeText(this, "A folder with that name already exists", Toast.LENGTH_SHORT).show()
                    } else {
                        folders.add(name)
                        prefs.edit().putStringSet("folders", folders).apply()
                        Toast.makeText(this, "Folder created", Toast.LENGTH_SHORT).show()
                        renderHome()
                    }
                }
            }.show()
    }

    private fun addAppToFolder(app: AppEntry) {
        val folders = (prefs.getStringSet("folders", emptySet()) ?: emptySet()).toList()
        if (folders.isEmpty()) {
            AlertDialog.Builder(this).setMessage("Create a folder first?").setNegativeButton("Cancel", null)
                .setPositiveButton("Create") { _, _ -> createFolderDialog() }.show()
            return
        }
        AlertDialog.Builder(this).setTitle("Add ${app.label} to folder").setItems(folders.toTypedArray()) { _, which ->
            val key = "folder_apps_${folders[which]}"
            val members = (prefs.getStringSet(key, emptySet()) ?: emptySet()).toMutableSet()
            members.add(app.packageName)
            prefs.edit().putStringSet(key, members).apply()
            Toast.makeText(this, "Added to ${folders[which]}", Toast.LENGTH_SHORT).show()
        }.show()
    }

    private fun showFolderActions(name: String) {
        AlertDialog.Builder(this).setTitle(name)
            .setItems(arrayOf("Rename folder", "Delete folder")) { _, which ->
                if (which == 0) {
                    val input = EditText(this).apply { setText(name); setSingleLine(true) }
                    AlertDialog.Builder(this).setTitle("Rename folder").setView(input)
                        .setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                            val next = input.text.toString().trim()
                            if (next.isNotEmpty() && next != name) {
                                val folders = (prefs.getStringSet("folders", emptySet()) ?: emptySet()).toMutableSet()
                                if (folders.contains(next)) {
                                    Toast.makeText(this, "A folder with that name already exists", Toast.LENGTH_SHORT).show()
                                } else {
                                    folders.remove(name); folders.add(next)
                                    val members = prefs.getStringSet("folder_apps_$name", emptySet()) ?: emptySet()
                                    prefs.edit().putStringSet("folders", folders).putStringSet("folder_apps_$next", members).remove("folder_apps_$name").apply()
                                    renderHome()
                                }
                            }
                        }.show()
                } else {
                    AlertDialog.Builder(this).setMessage("Delete '$name'? Apps will remain installed.")
                        .setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
                            val folders = (prefs.getStringSet("folders", emptySet()) ?: emptySet()).toMutableSet()
                            folders.remove(name)
                            prefs.edit().putStringSet("folders", folders).remove("folder_apps_$name").apply()
                            renderHome()
                        }.show()
                }
            }.show()
    }

    private fun showFolder(name: String) {
        screen = "folder"
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(48), dp(22), dp(20)); setBackgroundColor(backgroundColor) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(actionText("‹") { renderHome() })
        header.addView(TextView(this).apply { text = name; textSize = 26f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink); setPadding(dp(10), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(actionText("＋", blue) { addAppToFolderDialog(name) })
        page.addView(header)
        val members = prefs.getStringSet("folder_apps_$name", emptySet()) ?: emptySet()
        val grid = GridLayout(this).apply { columnCount = if (resources.configuration.screenWidthDp >= 600) 6 else (prefs.getString("columns", "4")?.toIntOrNull() ?: 4); useDefaultMargins = false }
        members.mapNotNull { pkg -> apps.firstOrNull { it.packageName == pkg } }.forEach { app ->
            val cell = appIcon(app, false, false)
            cell.setOnLongClickListener {
                AlertDialog.Builder(this).setTitle(app.label).setMessage("Remove this app from '$name'?")
                    .setNegativeButton("Cancel", null).setPositiveButton("Remove") { _, _ ->
                        val updated = (prefs.getStringSet("folder_apps_$name", emptySet()) ?: emptySet()).toMutableSet()
                        updated.remove(app.packageName); prefs.edit().putStringSet("folder_apps_$name", updated).apply(); showFolder(name)
                    }.show()
                true
            }
            grid.addView(cell, GridLayout.LayoutParams().apply { width = resources.displayMetrics.widthPixels / grid.columnCount - dp(12); height = dp(104); setMargins(dp(2), dp(4), dp(2), dp(4)) })
        }
        if (members.isEmpty()) page.addView(TextView(this).apply { text = "This folder is empty. Tap + to add apps."; textSize = 14f; setTextColor(muted); setPadding(0, dp(24), 0, 0) })
        val gridScroll = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        gridScroll.addView(grid)
        page.addView(gridScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
        animateScreen(page)
    }

    private fun addAppToFolderDialog(folder: String) {
        val members = prefs.getStringSet("folder_apps_$folder", emptySet()) ?: emptySet()
        val candidates = apps.filter { !members.contains(it.packageName) }
        if (candidates.isEmpty()) { Toast.makeText(this, "No more apps to add", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Add apps").setItems(candidates.map { it.label }.toTypedArray()) { _, which ->
            val updated = (prefs.getStringSet("folder_apps_$folder", emptySet()) ?: emptySet()).toMutableSet()
            updated.add(candidates[which].packageName)
            prefs.edit().putStringSet("folder_apps_$folder", updated).apply()
            showFolder(folder)
        }.show()
    }

    private fun showEditPanel() {
        screen = "edit"
        val overlay = FrameLayout(this).apply { setBackgroundColor(0x66000000) }
        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(20), dp(22), dp(26)); background = rounded(if (isDark()) Color.rgb(31, 35, 43) else Color.rgb(247, 249, 253), 30f)
        }
        val handle = View(this).apply { background = rounded(if (isDark()) 0xff626977.toInt() else 0xffc6ccd6.toInt(), 5f) }
        sheet.addView(handle, LinearLayout.LayoutParams(dp(42), dp(5)).apply { gravity = Gravity.CENTER; bottomMargin = dp(18) })
        sheet.addView(TextView(this).apply { text = "Home screen edit"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink) })
        sheet.addView(TextView(this).apply { text = "Personalise your DDUI space"; textSize = 13f; setTextColor(muted); setPadding(0, dp(4), 0, dp(18)) })
        val actions = listOf(
            LauncherAction("Wallpaper", "Change background", "▧") { openWallpaperPicker() },
            LauncherAction("Widgets", "Add Android widgets", "▦") { pickWidget() },
            LauncherAction("Folders", "Create and organise app folders", "▣") { createFolderDialog() },
            LauncherAction("Arrange apps", "Reorder your home favourites", "↕") { showFavoriteOrganizer() },
            LauncherAction("Themes", "Colours and appearance", "◐") { showSettings("appearance") },
            LauncherAction("Home settings", "Layout, gestures and effects", "⚙") { showSettings("home") }
        )
        actions.forEach { item ->
            val title = item.title
            val detail = item.detail
            val symbol = item.symbol
            val action = item.action
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)); background = rounded(surface, 18f); setOnClickListener { action() } }
            row.addView(TextView(this).apply { text = symbol; textSize = 24f; setTextColor(blue); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(48), dp(48)))
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
            texts.addView(TextView(this).apply { text = title; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink) })
            texts.addView(TextView(this).apply { text = detail; textSize = 12f; setTextColor(muted); setPadding(0, dp(3), 0, 0) })
            row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this).apply { text = "›"; textSize = 24f; setTextColor(muted) })
            sheet.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        }
        sheet.addView(actionText("Done", blue) { renderHome() }.apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(4)) })
        val lp = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { leftMargin = dp(8); rightMargin = dp(8); bottomMargin = dp(8) }
        overlay.addView(sheet, lp)
        overlay.setOnClickListener { renderHome() }
        sheet.setOnClickListener { }
        setContentView(overlay)
        sheet.translationY = dp(500).toFloat()
        sheet.animate().translationY(0f).setDuration(380).setInterpolator(OvershootInterpolator(.85f)).start()
    }

    private fun showSettings(section: String = "home") {
        applySystemBars()
        screen = "settings"
        val scroll = ScrollView(this).apply { setBackgroundColor(backgroundColor); overScrollMode = View.OVER_SCROLL_NEVER }
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(48), dp(22), dp(28)) }
        scroll.addView(page)
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(actionText("‹") { renderHome() }, LinearLayout.LayoutParams(dp(42), dp(48)))
        header.addView(TextView(this).apply { text = "Settings"; textSize = 29f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink) })
        page.addView(header)
        page.addView(TextView(this).apply { text = "Make your home feel like yours"; textSize = 13f; setTextColor(muted); setPadding(0, dp(4), 0, dp(20)) })

        addSettingsSection(page, "Appearance")
        val themeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("light" to "Light", "dark" to "Dark", "system" to "System").forEach { (value, label) ->
            val selected = prefs.getString("theme", "light") == value
            val chip = pill((if (selected) "✓  " else "") + label, 13f).apply {
                gravity = Gravity.CENTER; setBackground(rounded(if (selected) blue else surface, 20f)); setTextColor(if (selected) Color.WHITE else ink)
                setOnClickListener { prefs.edit().putString("theme", value).apply(); showSettings("appearance") }
            }
            themeRow.addView(chip, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        page.addView(themeRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        settingSwitch(page, "Show wallpaper", "Use your system wallpaper behind the launcher", "show_wallpaper", true)
        settingSwitch(page, "Show icon labels", "Display app names below icons", "show_labels", true)

        addSettingsSection(page, "Home screen")
        settingChoice(page, "Home columns", "Number of icons across the home screen", "home_columns", listOf("3", "4", "5", "6"), "4")
        settingChoice(page, "Drawer columns", "Number of icons across the app drawer", "columns", listOf("4", "5", "6"), "4")
        settingChoice(page, "Icon size", "Adjust app icon scale", "icon_size", listOf("44", "48", "52", "56", "60"), "50")
        settingChoice(page, "Icon shape", "Choose the DDUI icon tile shape", "icon_shape", listOf("Squircle", "Rounded", "Circle"), "Squircle")
        settingRow(page, "Icon pack", "Apply a compatible third-party icon pack", "Choose installed icon pack") { showIconPackPicker() }
        settingChoice(page, "App sorting", "Choose how apps are ordered", "app_sort", listOf("Name", "Usage", "Recently added"), "Name")
        settingChoice(page, "Accent colour", "Choose DDUI highlight colour", "accent", listOf("Blue", "Violet", "Mint", "Rose"), "Blue")
        settingSwitch(page, "Discover page", "Swipe right from Home to open DDUI Discover", "discover_enabled", true)
        settingSwitch(page, "Favourite dock", "Show the pinned app dock", "dock_enabled", true)

        addSettingsSection(page, "Motion & interaction")
        settingChoice(page, "Animation style", "Choose how screens and icons move", "animation_style", listOf("Smooth", "Spring", "Soft"), "Spring")
        settingSwitch(page, "Haptic feedback", "Vibrate lightly on launcher actions", "haptics", true)
        settingSwitch(page, "Swipe down enabled", "Allow a downward home gesture", "swipe_control", true)
        val gestureActions = listOf("None", "Control centre", "App drawer", "Discover", "Search", "Home")
        settingChoice(page, "Swipe up", "Choose the upward home gesture", "gesture_up", gestureActions, "App drawer")
        settingChoice(page, "Swipe down", "Choose the downward home gesture", "gesture_down", gestureActions, "Control centre")
        settingChoice(page, "Swipe left", "Choose the leftward home gesture", "gesture_left", gestureActions, "App drawer")
        settingChoice(page, "Swipe right", "Choose the rightward home gesture", "gesture_right", gestureActions, "Discover")

        addSettingsSection(page, "Discover & search")
        settingRow(page, "Search provider", "Google web search", "Choose where searches open") {
            val providers = arrayOf("Google", "DuckDuckGo", "Bing")
            AlertDialog.Builder(this).setTitle("Search provider").setSingleChoiceItems(providers, prefs.getInt("search_provider", 0)) { dialog, which -> prefs.edit().putInt("search_provider", which).apply(); dialog.dismiss(); showSettings("search") }.show()
        }
        settingSwitch(page, "Notification badges", "Display unread counts on app icons", "notification_badges", true)
        settingRow(page, "Notification access", "Allow DDUI to read notification counts", "Open notification access") { openNotificationAccess() }
        settingRow(page, "Backup & restore", "Export or restore DDUI layout and preferences", "Manage local backup") { showBackupDialog() }
        settingRow(page, "Hidden apps", "Manage apps hidden from the drawer", "Restore hidden apps") { manageHiddenApps() }
        settingRow(page, "About DDUI", "Version 0.3 · HyperOS-inspired", "Project information") { showAbout() }
        page.addView(actionText("Back to Home  ›", blue) { renderHome() }.apply { gravity = Gravity.CENTER; setPadding(0, dp(22), 0, dp(10)) })
        setContentView(scroll)
        animateScreen(scroll)
    }

    private fun addSettingsSection(parent: LinearLayout, title: String) {
        parent.addView(TextView(this).apply { text = title; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(blue); setPadding(dp(2), dp(18), 0, dp(9)) })
    }

    private fun settingSwitch(parent: LinearLayout, title: String, detail: String, key: String, default: Boolean) {
        val row = settingContainer(parent, title, detail)
        val sw = Switch(this).apply { isChecked = prefs.getBoolean(key, default); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() } }
        row.addView(sw)
    }

    private fun settingChoice(parent: LinearLayout, title: String, detail: String, key: String, choices: List<String>, default: String) {
        settingContainer(parent, title, detail).apply {
            val current = prefs.getString(key, default) ?: default
            addView(TextView(this@LauncherActivity).apply { text = current; textSize = 13f; setTextColor(blue) })
            setOnClickListener {
                AlertDialog.Builder(this@LauncherActivity).setTitle(title).setSingleChoiceItems(choices.toTypedArray(), choices.indexOf(current).coerceAtLeast(0)) { dialog, which ->
                    prefs.edit().putString(key, choices[which]).apply()
                    if (key == "app_sort") loadApps()
                    dialog.dismiss(); showSettings()
                }.setNegativeButton("Cancel", null).show()
            }
        }
    }

    private fun settingRow(parent: LinearLayout, title: String, detail: String, hint: String, action: () -> Unit) {
        settingContainer(parent, title, detail).apply {
            addView(TextView(this@LauncherActivity).apply { text = "›"; textSize = 23f; setTextColor(muted) })
            setOnClickListener { action() }
        }
    }

    private fun settingContainer(parent: LinearLayout, title: String, detail: String): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(15), dp(12), dp(13), dp(12)); background = rounded(surface, 18f)
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(TextView(this).apply { text = title; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink) })
        texts.addView(TextView(this).apply { text = detail; textSize = 11f; setTextColor(muted); setPadding(0, dp(3), 0, 0) })
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        return row
    }

    private fun showDiscover() {
        if (!prefs.getBoolean("discover_enabled", true)) { showDrawer(); return }
        applySystemBars()
        screen = "discover"
        val scroll = ScrollView(this).apply { setBackgroundColor(backgroundColor); overScrollMode = View.OVER_SCROLL_NEVER }
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(48), dp(22), dp(28)) }
        scroll.addView(page)
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply { text = "Discover"; textSize = 31f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink) }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(actionText("⚙") { showSettings("search") })
        page.addView(header)
        page.addView(TextView(this).apply { text = "Your space to explore"; textSize = 13f; setTextColor(muted); setPadding(0, dp(3), 0, dp(18)) })
        val search = EditText(this).apply {
            hint = "Search the web"; textSize = 15f; setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_SEARCH
            setTextColor(ink); setHintTextColor(muted); background = rounded(surface, 25f); setPadding(dp(17), 0, dp(17), 0)
            setOnEditorActionListener { _, actionId, _ -> if (actionId == EditorInfo.IME_ACTION_SEARCH) { performWebSearch(text.toString()); true } else false }
        }
        page.addView(search, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(18) })
        page.addView(discoverCard("Good morning", SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date()), "☼", surface) { showControlCenter() })
        page.addView(discoverCard("Google Discover", "Open the Google app's personalised feed", "G", surface) { openGoogleDiscover() }.apply { setPadding(dp(16), dp(12), dp(16), dp(12)) })
        page.addView(TextView(this).apply { text = "Quick access"; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink); setPadding(0, dp(20), 0, dp(10)) })
        val quick = GridLayout(this).apply { columnCount = 2; useDefaultMargins = false }
        listOf(
            LauncherAction("Wallpaper", "Personalise your screen", "▧") { openWallpaperPicker() },
            LauncherAction("Widgets", "Add glanceable information", "▦") { pickWidget() },
            LauncherAction("Themes", "Change the look", "◐") { showSettings("appearance") },
            LauncherAction("Settings", "Tune your launcher", "⚙") { showSettings() }
        ).forEach { item ->
            val card = discoverCard(item.title, item.detail, item.symbol, surface, item.action)
            quick.addView(card, GridLayout.LayoutParams().apply { width = resources.displayMetrics.widthPixels / 2 - dp(32); setMargins(dp(3), dp(3), dp(3), dp(3)) })
        }
        page.addView(quick)
        page.addView(TextView(this).apply { text = "Explore"; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink); setPadding(0, dp(20), 0, dp(10)) })
        page.addView(discoverCard("Search for anything", "Open a web search with your selected provider", "⌕", surface) { performWebSearch("") })
        page.addView(discoverCard("Your apps", "Find, organise and pin your favourite apps", "▦", surface) { showDrawer() })
        page.addView(actionText("‹  Back to Home", blue) { renderHome() }.apply { setPadding(0, dp(22), 0, dp(8)) })
        setContentView(scroll)
        animateScreen(scroll)
    }

    private fun discoverCard(title: String, detail: String, symbol: String, bg: Int, action: () -> Unit): View {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(15)); background = rounded(bg, 22f); elevation = dp(1).toFloat(); setOnClickListener { action() } }
        card.addView(TextView(this).apply { text = symbol; textSize = 22f; setTextColor(blue) })
        card.addView(TextView(this).apply { text = title; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink); setPadding(0, dp(7), 0, dp(3)) })
        card.addView(TextView(this).apply { text = detail; textSize = 11f; setTextColor(muted); maxLines = 2 })
        return card
    }

    private fun openGoogleDiscover() {
        val intent = packageManager.getLaunchIntentForPackage("com.google.android.googlequicksearchbox")
        if (intent != null) {
            try { startActivity(intent) } catch (_: Exception) { performWebSearch("") }
        } else {
            AlertDialog.Builder(this).setMessage("Google app is not installed. DDUI Discover can still search the web.")
                .setPositiveButton("Search web") { _, _ -> performWebSearch("") }.setNegativeButton("Cancel", null).show()
        }
    }

    private fun performWebSearch(query: String) {
        val provider = when (prefs.getInt("search_provider", 0)) { 1 -> "https://duckduckgo.com/?q="; 2 -> "https://www.bing.com/search?q="; else -> "https://www.google.com/search?q=" }
        val uri = android.net.Uri.parse(provider + android.net.Uri.encode(query))
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) { Toast.makeText(this, "No browser available", Toast.LENGTH_SHORT).show() }
    }

    private fun showControlCenter() {
        applySystemBars()
        screen = "control"
        val scroll = ScrollView(this).apply { setBackgroundColor(backgroundColor) }
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(48), dp(22), dp(26)) }
        scroll.addView(page)
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply { text = "Control centre"; textSize = 27f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink) }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(actionText("Done  ✓", blue) { renderHome() })
        page.addView(top)
        page.addView(TextView(this).apply { text = SimpleDateFormat("EEEE, MMM d  ·  HH:mm", Locale.getDefault()).format(Date()); textSize = 13f; setTextColor(muted); setPadding(0, dp(4), 0, dp(18)) })
        val grid = GridLayout(this).apply { columnCount = 2; useDefaultMargins = false }
        val tiles = listOf(
            Triple("Wi-Fi", "Network settings", Settings.ACTION_WIFI_SETTINGS), Triple("Bluetooth", "Connected devices", Settings.ACTION_BLUETOOTH_SETTINGS),
            Triple("Display", "Brightness and display", Settings.ACTION_DISPLAY_SETTINGS), Triple("Sound", "Sound and vibration", Settings.ACTION_SOUND_SETTINGS),
            Triple("Battery", "Battery settings", Settings.ACTION_BATTERY_SAVER_SETTINGS), Triple("Settings", "System settings", Settings.ACTION_SETTINGS)
        )
        tiles.forEach { (title, detail, action) ->
            val tile = discoverCard(title, detail, "●", surface) { try { startActivity(Intent(action)) } catch (_: Exception) { } }
            grid.addView(tile, GridLayout.LayoutParams().apply { width = resources.displayMetrics.widthPixels / 2 - dp(32); setMargins(dp(3), dp(3), dp(3), dp(3)) })
        }
        page.addView(grid)
        page.addView(TextView(this).apply { text = "Launcher shortcuts"; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink); setPadding(0, dp(20), 0, dp(8)) })
        page.addView(discoverCard("DDUI settings", "Personalise themes, icons and gestures", "⚙", surface) { showSettings() })
        setContentView(scroll)
        animateScreen(scroll)
    }

    private fun batteryPercent(): Int = try {
        val manager = getSystemService(android.os.BatteryManager::class.java)
        manager.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
    } catch (_: Exception) { 0 }

    private fun infoTile(title: String, value: String, symbol: String): View {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10)); background = rounded(surface, 21f)
            setOnClickListener {
                when (title) {
                    "QUICK NOTE" -> showNoteDialog()
                    "BATTERY" -> try { startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) } catch (_: Exception) { }
                    else -> pickWidget()
                }
            }
        }
        tile.addView(TextView(this@LauncherActivity).apply { text = symbol; textSize = 18f; setTextColor(blue) })
        tile.addView(TextView(this@LauncherActivity).apply { text = title; textSize = 9f; letterSpacing = .08f; setTextColor(muted); setPadding(0, dp(3), 0, 0) })
        tile.addView(TextView(this@LauncherActivity).apply { text = value; textSize = 12f; setTextColor(ink); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(0, dp(3), 0, 0) })
        return tile
    }

    private fun showNoteDialog() {
        val input = EditText(this).apply { hint = "Write a quick note"; setText(prefs.getString("note", "")) }
        AlertDialog.Builder(this).setTitle("Quick note").setView(input).setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ -> prefs.edit().putString("note", input.text.toString()).apply(); renderHome() }.show()
    }

    private fun openWallpaperPicker() {
        try { startActivity(Intent(Intent.ACTION_SET_WALLPAPER)) } catch (_: Exception) { Toast.makeText(this, "Wallpaper settings unavailable", Toast.LENGTH_SHORT).show() }
    }

    private fun pickWidget() {
        try {
            val id = widgetHost.allocateAppWidgetId()
            pendingWidgetId = id
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            startActivityForResult(intent, widgetRequest)
        } catch (_: Exception) { Toast.makeText(this, "Widget picker unavailable on this device", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == widgetRequest) {
            val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId) ?: pendingWidgetId
            if (resultCode == RESULT_OK && id > 0) {
                val info = widgetManager.getAppWidgetInfo(id)
                if (info?.configure != null) {
                    pendingWidgetId = id
                    val configure = Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE)
                        .setComponent(info.configure)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    try { startActivityForResult(configure, widgetConfigureRequest) }
                    catch (_: Exception) { saveWidgetId(id) }
                } else saveWidgetId(id)
            } else if (id > 0) widgetHost.deleteAppWidgetId(id)
            if (resultCode != RESULT_OK) pendingWidgetId = -1
        } else if (requestCode == widgetConfigureRequest) {
            val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId) ?: pendingWidgetId
            if (resultCode == RESULT_OK && id > 0) saveWidgetId(id)
            else if (id > 0) widgetHost.deleteAppWidgetId(id)
            pendingWidgetId = -1
        } else if (requestCode == backupExportRequest && resultCode == RESULT_OK && data?.data != null) {
            exportBackup(data.data!!)
        } else if (requestCode == backupImportRequest && resultCode == RESULT_OK && data?.data != null) {
            importBackup(data.data!!)
        }
    }

    private fun saveWidgetId(id: Int) {
        val ids = (prefs.getStringSet("widget_ids", emptySet()) ?: emptySet()).toMutableSet()
        ids.add(id.toString()); prefs.edit().putStringSet("widget_ids", ids).apply()
        pendingWidgetId = -1
        renderHome()
    }

    private fun usageCount(pkg: String): Int = (prefs.getStringSet("app_usage", emptySet()) ?: emptySet())
        .firstOrNull { it.startsWith("$pkg=") }?.substringAfter('=')?.toIntOrNull() ?: 0

    private fun appInstallTime(pkg: String): Long = try {
        packageManager.getPackageInfo(pkg, 0).firstInstallTime
    } catch (_: Exception) { 0L }

    private fun notificationCount(pkg: String): Int = (prefs.getStringSet("notification_counts", emptySet()) ?: emptySet())
        .firstOrNull { it.startsWith("$pkg=") }?.substringAfter('=')?.toIntOrNull() ?: 0

    private fun openNotificationAccess() {
        try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        catch (_: Exception) { Toast.makeText(this, "Notification access settings unavailable", Toast.LENGTH_SHORT).show() }
    }

    private fun showBackupDialog() {
        AlertDialog.Builder(this).setTitle("Backup & restore")
            .setItems(arrayOf("Export backup", "Restore backup")) { _, which ->
                if (which == 0) {
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "DDUI-backup.json")
                    }
                    startActivityForResult(intent, backupExportRequest)
                } else {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json" }
                    startActivityForResult(intent, backupImportRequest)
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun exportBackup(uri: Uri) {
        try {
            val json = JSONObject().put("_ddui_backup_version", 1).put("_ddui_app", "DDUI")
            prefs.all.forEach { (key, value) ->
                when (value) {
                    is Set<*> -> json.put(key, JSONArray(value.filterIsInstance<String>()))
                    is String, is Boolean, is Int, is Long, is Float -> json.put(key, value)
                    else -> Unit
                }
            }
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(json.toString(2)) }
                ?: throw IllegalStateException("Unable to open destination")
            Toast.makeText(this, "Backup exported", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Backup export failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importBackup(uri: Uri) {
        try {
            val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: throw IllegalStateException("Unable to read backup")
            val json = JSONObject(raw)
            if (json.optInt("_ddui_backup_version", 0) != 1 || json.optString("_ddui_app") != "DDUI") {
                throw IllegalArgumentException("This is not a supported DDUI backup")
            }
            val editor = prefs.edit().clear()
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next(); val value = json.get(key)
                when (value) {
                    is JSONArray -> {
                        val values = mutableSetOf<String>()
                        for (i in 0 until value.length()) if (!value.isNull(i)) values.add(value.getString(i))
                        editor.putStringSet(key, values)
                    }
                    is Boolean -> editor.putBoolean(key, value)
                    is Int -> editor.putInt(key, value)
                    is Long -> editor.putLong(key, value)
                    is Double -> editor.putFloat(key, value.toFloat())
                    is String -> editor.putString(key, value)
                }
            }
            editor.apply(); loadApps(); renderHome()
            Toast.makeText(this, "Backup restored", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Backup restore failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun manageHiddenApps() {
        val hidden = (prefs.getStringSet("hidden_apps", emptySet()) ?: emptySet()).toMutableSet()
        val labels = hidden.map { pkg ->
            try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
        }.toTypedArray()
        if (labels.isEmpty()) { AlertDialog.Builder(this).setMessage("No hidden apps").setPositiveButton("OK", null).show(); return }
        AlertDialog.Builder(this).setTitle("Hidden apps").setItems(labels) { _, which ->
            hidden.remove(hidden.elementAt(which)); prefs.edit().putStringSet("hidden_apps", hidden).apply(); loadApps(); showSettings()
        }.show()
    }

    private fun showAbout() {
        AlertDialog.Builder(this).setTitle("DDUI").setMessage("DDUI 0.5.0\nAn independently developed Android launcher inspired by modern Android home-screen interaction patterns.\n\nIncludes multi-page home screens, original icon artwork, app organisation, widgets, Discover, notification badges, themes, gestures and local backup/restore.\n\nNot affiliated with Xiaomi.")
            .setPositiveButton("OK", null).show()
    }

    private fun pill(text: String, size: Float = 12f): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(ink); gravity = Gravity.CENTER
        setPadding(dp(14), dp(9), dp(14), dp(9)); background = rounded(surface, 30f)
    }

    private fun actionText(text: String, color: Int = ink, action: () -> Unit): TextView = TextView(this).apply {
        this.text = text; textSize = 16f; setTextColor(color); gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun iconFrameBackground(): GradientDrawable = GradientDrawable().apply {
        setColor(if (isDark()) Color.rgb(49, 54, 65) else Color.argb(42, 255, 255, 255))
        when (prefs.getString("icon_shape", "Squircle")) {
            "Circle" -> shape = GradientDrawable.OVAL
            "Rounded" -> cornerRadius = dp(13).toFloat()
            else -> cornerRadius = dp(20).toFloat()
        }
    }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun dp(v: Float): Int = (v * resources.displayMetrics.density).toInt()

    private fun animateScreen(view: View) {
        when (prefs.getString("animation_style", "Spring")) {
            "Smooth" -> {
                view.alpha = 0f; view.translationY = dp(12).toFloat()
                view.animate().alpha(1f).translationY(0f).setDuration(240).setInterpolator(DecelerateInterpolator(1.6f)).start()
            }
            "Soft" -> {
                view.alpha = 0f; view.scaleX = .985f; view.scaleY = .985f
                view.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420).setInterpolator(DecelerateInterpolator(1.2f)).start()
            }
            else -> {
                view.alpha = 0f; view.scaleX = .975f; view.scaleY = .975f; view.translationY = dp(16).toFloat()
                view.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(360).setInterpolator(OvershootInterpolator(.75f)).start()
            }
        }
    }

    private fun animateChildren(parent: ViewGroup) {
        for (i in 0 until parent.childCount) {
            val child = parent.getChildAt(i)
            child.alpha = 0f; child.translationY = dp(13).toFloat()
            child.animate().alpha(1f).translationY(0f).setStartDelay((i * 28L).coerceAtMost(220L)).setDuration(300).setInterpolator(DecelerateInterpolator(1.5f)).start()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) {
            "home" -> super.onBackPressed()
            "discover", "drawer", "control", "settings", "edit", "folder" -> renderHome()
            else -> renderHome()
        }
    }
}
