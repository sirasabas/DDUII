package com.ddui.launcher

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Stores per-package active notification counts for DDUI icon badges. */
class DDUINotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) = refreshCounts()
    override fun onNotificationRemoved(sbn: StatusBarNotification) = refreshCounts()

    override fun onListenerConnected() = refreshCounts()

    private fun refreshCounts() {
        try {
            val counts = activeNotifications.orEmpty()
                .filterNot { it.packageName == packageName }
                .groupingBy { it.packageName }
                .eachCount()
                .map { (pkg, count) -> "$pkg=$count" }
                .toSet()
            getSharedPreferences("ddui", MODE_PRIVATE).edit()
                .putStringSet("notification_counts", counts)
                .apply()
            sendBroadcast(android.content.Intent("$packageName.NOTIFICATIONS_UPDATED").setPackage(packageName))
        } catch (_: SecurityException) {
            // Access can be revoked while the service is running.
        } catch (_: IllegalStateException) {
            // Service may be disconnected during shutdown.
        }
    }
}
